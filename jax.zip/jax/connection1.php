<?php
$connect=mysqli_connect("localhost","root","","jax");
?>