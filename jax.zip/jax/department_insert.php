<?php
include_once("connection1.php");
if($_POST)
{
 $connect=mysqli_connect("localhost","root","");
 $db=mysqli_select_db($connect,"jax");

 $Name=$_POST['department'];



  $query=mysqli_query($connect,"INSERT INTO `deparment`( `department`) VALUES ('$Name')");
  if($query)
{
	echo "Successfully";
}
 }
?>