<?php
include_once("connection1.php");
if($_POST)
{
 $connect=mysqli_connect("localhost","root","");
 $db=mysqli_select_db($connect,"jax");
 $Item_Name=$_POST['item_name'];
 $Purchase_From=$_POST['purchase_from'];
 $Purchase_Date=$_POST['purchase_date'];
 $Purchased_By=$_POST['purchase_by'];
 $Amount=$_POST['amount'];
 $Paid_By=$_POST['paid_By'];
 $Status=$_POST['status'];
 $Attachments=$_POST['attachments'];
 

  $query=mysqli_query($connect,"INSERT INTO `expenses`(`item_name`, `purchase_from`, `purchase_date`, `purchase_by`, `amount`, `paid_By`, `status`, `attachments`) VALUES ('$Item_Name','$Purchase_From','$Purchase_Date','$Purchased_By','$Amount','$Paid_By','$Status','$Attachments')");
  if($query)
{
	echo "Successfully";
}
 }
?>