<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #f7f7f7">
	<div class="container">
		<h2><div class="well text-center"> Admin Panel</div></h2>
	</div>
	<div class="panel panel-default">
	<div class="panel-heading">
		<h2>
		<a class="btn btn-success" href="leave(admin).php">View All</a>
		<a class="btn btn-info pull-right" href=""> Back </a>
		</h2>
	</div>
	<table class="table table-striped">
	    <thead>
	      <tr>
	        <th>Employee</th>
	        <th>Leave Type</th>
	        <th>From</th>
	         <th>To</th>
	        <th>No of Days</th>
	        <th>Reasons</th>
	        <th>Status</th>
	         <th>Action</th>
	      </tr>
	    </thead>
	    <tbody>
    	<?php
		include_once("connection1.php");
		$query=mysqli_query($connect,"SELECT * FROM `leave` ");
		while($rows = mysqli_fetch_assoc($query))
	{?>
      <tr>
        <td><?php echo $rows ['employee'];?></td>
        <td><?php echo $rows ['Leave'];?></td>
        <td><?php echo $rows ['From'];?></td>
        <td><?php echo $rows ['To'];?></td>
        <td><?php echo $rows ['Days'];?></td>
        <td><?php echo $rows ['Reason'];?></td>
         <?php
         	$status = "";
	         if($rows ['status'] == 0)
	          		$status = "Not approved";
	         elseif($rows['status'] == 1)
	          		$status ="Approved";
	          		
	      	else
	      		$status = "Reject";

          ?>
        <td><?php echo $status ?></td>
        <td><a href="leaveupdate.php?id=<?php echo $rows['id']?>"> update</a></td>
      </tr>
  
  <?php } ?>
  </tbody>
</table>
</div>
<!--attendaance-->
<div class="panel panel-default">
	<div class="panel-heading">
		<h2>
		<a class="btn btn-success" href="employeeattendance.php">View All</a>
		<a class="btn btn-info pull-right" href=""> Back </a>
		</h2>
	</div>
	<table class="table table-striped">
	    <thead>
	      <tr>
	        
            
            <th>Name</th>
            <th>Email_Id</th>
             <th>Department</th>
            <th>Work_Description</th>
            <th>Date</th>
            <th>Total Hours</th>
            <th>Project</th>
           
          </tr>
        </thead>
    <tbody>
        <?php
        include_once("connection1.php");
        $query=mysqli_query($connect,"SELECT * FROM `attendance` ");
        while($rows = mysqli_fetch_assoc($query))
            
    
{?>
      <tr>
        <<td><?php echo $rows ['name'];?></td>
        <td><?php echo $rows ['email'];?></td>
        <td><?php echo $rows ['department'];?></td>
        <td><?php echo $rows ['work'];?></td>
        <td><?php echo $rows ['date'];?></td>
        <td><?php echo $rows ['hours'];?></td>
        <td><?php echo $rows['project'];?></td>
    </tr>
  
  <?php } ?>
  </tbody>                            
                                        
                                    </table>
                                </div>
                            </div>
                       
	      </tr>
	    </thead>
	    <tbody>
</body>
</html>
