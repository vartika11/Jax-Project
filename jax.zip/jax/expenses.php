<!DOCTYPE html>
<html lang="en">
    <head>        
        <!-- META SECTION -->
        <title>Expenses Report</title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        
        <link rel="icon" href="favicon.ico" type="image/x-icon" />
        <!-- END META SECTION -->
        
        <!-- CSS INCLUDE -->        
        <link rel="stylesheet" type="text/css" id="theme" href="css/full.css"/>
        <!-- EOF CSS INCLUDE -->                                     
    </head>
    <body>
        <!-- START PAGE CONTAINER -->
        <div class="page-container">
            
            <!-- START PAGE SIDEBAR -->
            <div class="page-sidebar">
                <!-- START X-NAVIGATION -->
                <ul class="x-navigation">
                    <li class="xn-logo">
                        <a href="index.php">Jax HealthCare</a>
                        <a href="#" class="x-navigation-control"></a>
                    </li>
                    <li class="xn-profile">
                        <a href="#" class="profile-mini">
                            <img src="" alt=""/>
                        </a>
                        <div class="profile">
                            <div class="profile-image">
                                <img src="jax.jpg" alt=""/>
                            </div>
                            <div class="profile-data">
                                <div class="profile-data-name">Admin</div>
                                
                            <div class="profile-controls">
                                <a href="pages-profile.html" class="profile-control-left"><span class="fa fa-info"></span></a>
                                <a href="pages-messages.html" class="profile-control-right"><span class="fa fa-envelope"></span></a>
                            </div>
                        </div>                                                                        
                    </li>
                    <li class="xn-title"></li>
                    <li class="active">
                        <a href="index.php"><span class="fa fa-tachometer"></span> <span class="xn-text">Dashboard</span></a>                        
                    </li>   
                    <li class="active">
                        <a href=""><span class="fas"></span> <span class="xn-text">Employee Dashboard</span></a>                        
                    </li>                    
                    <li class="xn-openable">
                        <a href="index.php"><span class="fa fa-user"></span> <span class="xn-text">Employees</span></a>
                        <ul>
                            <li><a href="allemployee.php"><span class=""></span>All Employees</a></li>
                            <li><a href="holiday.php"><span class=""></span> Holidays</a></li>
                            <li><a href="leave(admin).php"><span class=""></span> Leaves(admin)</a></li>
                            <li><a href="leave(employee).php"><span class=""></span> Leaves(employee)</a></li>
                             <li><a href=""><span class=""></span>Leave Setting</a></li>
                                <li><a href=""><span class=""></span>Attendance(Admin)</a></li>
                                <li><a href="employeeattendance.php"><span class=""></span>Attendance(employee)</a></li>
                                <li><a href="department.php"><span class=""></span>Department</a></li>
                                <li><a href="designation.php"><span class=""></span>Designation</a></li>
                                <li><a href="timesheet.php"><span class=""></span>Timesheet</a></li>
                                <li><a href="performance.php"><span class=""></span>Performance Review</a></li>
                                <li><a href="promotion.php"><span class=""></span>Promotion</a></li>
                                <li><a href="resignation.php"><span class=""></span>Resignation</a></li>
                                <li><a href="termination.php"><span class=""></span>Termination</a></li>
                                <li><a href="overtime.php"><span class=""></span>Overtime</a></li>
                            
                        </li>

                            
                        </ul>
                    </li>
                    
                    <li>
                        <a href=""><span class=""></span> <span class="xn-text">Clients</span></a>
                    </li>   
                    <li>
                        <a href="project.php"><span class="fa fa-rocket"></span> <span class="xn-text">Projects</span></a>
                    </li>                   
                    <li>
                        <a href="task.php"><span class="fa fa-tasks"></span> <span class="xn-text">Tasks</span></a>
                    </li>   
                    <li class="xn-openable">
                        <a href=""><span class="fa fa-phone"></span> <span class="xn-text">Calls</span></a>
                        <ul>                            
                            <li><a href=""><span class=""></span> Incoming Call</a></li>
                            <li><a href=""><span class=""></span> Voice Call</a></li>
                            <li><a href=""><span class=""></span> Video call</a></li>                            
                        </ul>
                    </li>
                    
                    
                                     
                    
                    <li>
                        <a href=""><span class="fa fa-address-book"></span> <span class="xn-text">Contacts</span></a>
                    </li>   
                            
                            <li>
                        <a href=""><span class=""></span> <span class="xn-text">leads</span></a>
                    </li>   
                    <li class="xn-openable">
                        <a href=""><span class=""></span> <span class="xn-text">Accounts</span></a>
                        <ul>                            
                            <li><a href=""><span class=""></span> Estimates</a></li>
                            <li><a href=""><span class=""></span> Invoices</a></li>
                            <li><a href=""><span class=""></span>Payments </a></li>
                            <li><a href=""><span class=""></span> Expenses</a></li>                            
                            <li><a href="provident.php"><span class=""></span>Provident Fund </a></li>
                            <li><a href="taxes.php"><span class=""></span>Taxes </a></li>
                        </ul>
                    </li> 
                    <li class="xn-openable">
                        <a href="tables.html"><span class="fa fa-table"></span> <span class="xn-text">Payroll</span></a>
                        <ul>                            
                            <li><a href=""><span class=""></span> Employee salary</a></li>
                            <li><a href=""><span class=""></span> Payslip</a></li>
                            <li><a href=""><span class=""></span>Payroll Items </a></li>
                            
                        </ul>
                    </li> 
                            <li class="xn-openable">
                        <a href="tables.html"><span class="fa fa-table"></span> <span class="xn-text">Jobs</span></a>
                        <ul>                            
                            <li><a href="manage.php"><span class=""></span> Manage Jobs</a></li>
                            <li><a href=""><span class=""></span> Applied Jobs</a></li>
                            <li><a href=""><span class=""></span>Payroll Items </a></li>
                            
                        </ul>
                    </li> 
                    <li>
                        <a href="tickets.php"><span class=""></span> <span class="xn-text">Tickets</span></a>
                    </li>   
                    <li>
                        <a href="calendar.php"><span class="fa fa-calendar"></span> <span class="xn-text">Events</span></a>
                    </li>   
                    <li>
                        <a href=""><span class="fa fa-at"></span> <span class="xn-text">Email</span></a>
                    </li>   
                    <li>
                        <a href=""><span class=""></span> <span class="xn-text">Chats</span></a>
                    </li>   
                    <li>
                        <a href=""><span class=""></span> <span class="xn-text">Knowledgebase</span></a>
                    </li>   
                    <li>
                        <a href=""><span class=""></span> <span class="xn-text">Policies</span></a>
                    </li>  
                    <li>
                    <a href=""><span class="fa fa-bell-o"></span> <span class="xn-text">Activities</span></a>
                    </li>   
                    <li> 
                        <a href="users.php"><span class=""></span> <span class="xn-text">Users</span></a>
                    </li> 
                    <li class="xn-openable">
                        <a href=""><span class="fa fa-table"></span> <span class="xn-text">Reports</span></a>
                        <ul>                            
                            <li><a href=""><span class=""></span> Expenses Reports</a></li>
                            <li><a href=""><span class=""></span> Invoice Reports</a></li>   
                        </ul>
                    </li> 
                    <li>  
                    <a href=""><span class=""></span> <span class="xn-text">Settings</span></a>
                    </li> 
                    <li class="xn-openable">
                        <a href=""><span class=""></span> <span class="xn-text">Pages</span></a>
                        <ul>                            
                            <li><a href="login"><span class=""></span>Login </a></li>
                            <li><a href="registration.php"><span class=""></span> Register</a></li>   
                            <li><a href="forgotpass.php"><span class=""></span>Forgot Password </a></li>
                            <li><a href=""><span class=""></span>OTP </a></li>
                            <li><a href="login.php"><span class=""></span> Lock Screen</a></li>
                            <li><a href=""><span class=""></span>Employee Profile </a></li>
                            <li><a href=""><span class=""></span>Client Profile</a></li>
                            <li><a href="search.php"><span class=""></span>Search </a></li>
                            <li><a href="faq.php"><span class=""></span> FAQ</a></li>
                        
                        <li><a href=""><span class=""></span>Terms </a></li>
                        
                        <li><a href=""><span class=""></span>Privacy Policy </a></li>
                        
                        <li><a href="error.php"><span class=""></span> 404 Error</a></li>
                        
                        <li><a href="error-500.php"><span class=""></span>500 Error </a></li>
                        
                        <li><a href="blank.php"><span class=""></span> Blank Page</a></li>
                        
                       
                        </ul>
                    </li>  
                    <li>
                    <a href=""><span class=""></span> <span class="xn-text">Components</span></a>
                    </li>  
                           <li class="xn-openable">
                        <a href=""><span class=""></span> <span class="xn-text">Multilevel</span></a>
                        <ul>                            
                            <li><a href=""><span class=""></span>Level 1</a></li>
                            <li><a href=""><span class=""></span> Level 2</a></li>   
                        </ul>
                    </li> 
                            
                            
                <!-- END X-NAVIGATION -->
            </div>
            <!-- END PAGE SIDEBAR -->
            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START X-NAVIGATION VERTICAL -->
                <ul class="x-navigation x-navigation-horizontal x-navigation-panel">
                    <!-- TOGGLE NAVIGATION -->
                    <li class="xn-icon-button">
                        <a href="#" class="x-navigation-minimize"><span class="fa fa-dedent"></span></a>
                    </li>
                    <!-- END TOGGLE NAVIGATION -->
                    <!-- SEARCH -->
                    <li class="xn-search">
                        <form role="form">
                            <input type="text" name="search" placeholder="Search..."/>
                        </form>
                    </li>   
                    <!-- END SEARCH -->
                    <!-- SIGN OUT -->
                    <li class="xn-icon-button pull-right">
                        <a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span></a>                        
                    </li> 
                    <!-- END SIGN OUT -->
                    <!-- MESSAGES -->
                    <li class="xn-icon-button pull-right">
                        <a href="#"><span class="fa fa-comments"></span></a>
                        <div class="informer informer-danger">4</div>
                        <div class="panel panel-primary animated zoomIn xn-drop-left xn-panel-dragging">
                            <div class="panel-heading">
                                <h3 class="panel-title"><span class="fa fa-comments"></span> Messages</h3>                                
                                <div class="pull-right">
                                    <span class="label label-danger">4 new</span>
                                </div>
                            </div>
                            <div class="panel-body list-group list-group-contacts scroll" style="height: 200px;">
                                <a href="#" class="list-group-item">
                                    <div class="list-group-status status-online"></div>
                                    <img src="assets/images/users/user2.jpg" class="pull-left" alt="John Doe"/>
                                    <span class="contacts-title">John Doe</span>
                                    <p>Praesent placerat tellus id augue condimentum</p>
                                </a>
                                
                            <div class="panel-footer text-center">
                                <a href="">Show all messages</a>
                            </div>                            
                        </div>                        
                    </li>
                    <!-- END MESSAGES -->
                    <!-- TASKS -->
                    <li class="xn-icon-button pull-right">
                        <a href="#"><span class="fa fa-tasks"></span></a>
                        <div class="informer informer-warning">3</div>
                        <div class="panel panel-primary animated zoomIn xn-drop-left xn-panel-dragging">
                            <div class="panel-heading">
                                <h3 class="panel-title"><span class="fa fa-tasks"></span> Tasks</h3>                                
                                <div class="pull-right">
                                    <span class="label label-warning">active</span>
                                </div>
                            </div>
                            
                            <div class="panel-footer text-center">
                                <a href="task.php">Show all tasks</a>
                            </div>                            
                        </div>                        
                    </li>
                    <!-- END TASKS -->
                </ul>
                
                <div class="page-title">                    
                    <h2>Expenses</h2>
                </div>
                <!-- END PAGE TITLE -->                

                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">                
                
                    <div class="row">
                        <div class="col-md-12">

                            <!-- START DEFAULT DATATABLE -->
                            <div class="panel panel-default">
                                <div class="panel-heading">                                
                                    <!--<h3 class="panel-title">Default</h3>-->
                                    <ul class="panel-controls">
                                        <li><a href="#" class="panel-collapse"><span class="fa fa-angle-down"></span></a></li>
                                        <li><a href="#" class="panel-refresh"><span class="fa fa-refresh"></span></a></li>
                                        <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                                    </ul>                                
                                </div>
                                <div class="panel-body">
                                    <a class="btn btn-success" href="addexpenses.php" style="float: right; font-size: 25px">Add Expenses</a>  
                                    <table class="table datatable">
                                        <thead>
                                            <thead>
          <tr>
            
            <th>Item</th>
          <th>Purchase From</th>
          <th>Purchase Date</th>
          <th>Purchase By</th>
          <th>Amount</th>
          <th>Paid By</th>
          <th> Status</th>
          <th>Action</th>
                  </tr>
          <tbody>
        <?php
        include_once("connection1.php");
        $query=mysqli_query($connect,"SELECT * FROM `expenses` ");
        while($rows = mysqli_fetch_assoc($query))
    {?>
      <tr>
        <td><?php echo $rows ['item_name'];?></td>
        <td><?php echo $rows ['purchase_from'];?></td>
        <td><?php echo $rows ['purchase_date'];?></td>
        <td><?php echo $rows ['purchase_by'];?></td>
        <td><?php echo $rows ['amount'];?></td>
        <td><?php echo $rows ['paid_By'];?></td>
</tr>
</tbody>
<?php } ?>
</thead>
</table>
</form>
<!-- MESSAGE BOX-->
<div class="message-box animated fadeIn" data-sound="alert" id="mb-signout">
            <div class="mb-container">
                <div class="mb-middle">
                    <div class="mb-title"><span class="fa fa-sign-out"></span> Log <strong>Out</strong> ?</div>
                    <div class="mb-content">
                        <p>Are you sure you want to log out?</p>                    
                        <p>Press No if youwant to continue work. Press Yes to logout current user.</p>
                    </div>
                    <div class="mb-footer">
                        <div class="pull-right">
                            <a href="registration.php" class="btn btn-success btn-lg">Yes</a>
                            <button class="btn btn-default btn-lg mb-control-close">No</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END MESSAGE BOX-->

        <!-- START PRELOADS -->
        <audio id="audio-alert" src="audio/alert.mp3" preload="auto"></audio>
        <audio id="audio-fail" src="audio/fail.mp3" preload="auto"></audio>
        <!-- END PRELOADS -->                  
        
    <!-- START SCRIPTS -->
        <!-- START PLUGINS -->
        <script type="text/javascript" src="js/plugins/jquery/jquery.min.js"></script>
        <script type="text/javascript" src="js/plugins/jquery/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/plugins/bootstrap/bootstrap.min.js"></script>        
        <!-- END PLUGINS -->

        <!-- START THIS PAGE PLUGINS-->        
        <script type='text/javascript' src='js/plugins/icheck/icheck.min.js'></script>        
        <script type="text/javascript" src="js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
        <script type="text/javascript" src="js/plugins/scrolltotop/scrolltopcontrol.js"></script>
        
        <script type="text/javascript" src="js/plugins/morris/raphael-min.js"></script>
        <script type="text/javascript" src="js/plugins/morris/morris.min.js"></script>       
        <script type="text/javascript" src="js/plugins/rickshaw/d3.v3.js"></script>
        <script type="text/javascript" src="js/plugins/rickshaw/rickshaw.min.js"></script>
        <script type='text/javascript' src='js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js'></script>
        <script type='text/javascript' src='js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js'></script>                
        <script type='text/javascript' src='js/plugins/bootstrap/bootstrap-datepicker.js'></script>                
        <script type="text/javascript" src="js/plugins/owl/owl.carousel.min.js"></script>                 
        
        <script type="text/javascript" src="js/plugins/moment.min.js"></script>
        <script type="text/javascript" src="js/plugins/daterangepicker/daterangepicker.js"></script>
        <!-- END THIS PAGE PLUGINS-->        

        <!-- START TEMPLATE -->
        
        
        <script type="text/javascript" src="js/plugins.js"></script>        
        <script type="text/javascript" src="js/actions.js"></script>
        
        <script type="text/javascript" src="js/demo_dashboard.js"></script>
        <!-- END TEMPLATE -->
    <!-- END SCRIPTS -->         
    </body>
</html>

