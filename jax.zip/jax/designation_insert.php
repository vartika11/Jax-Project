<?php
include_once("connection1.php");
if($_POST)
{
 $connect=mysqli_connect("localhost","root","");
 $db=mysqli_select_db($connect,"jax");
 $designation_Name=$_POST['name'];
 $department_name=$_POST['department'];
 //$Day=$_['day']

 $query=mysqli_query($connect,"INSERT INTO `designation`(`name`, `department`) VALUES ('$designation_Name','$department_name')");
 if($query)
{
	echo "Successfully";
}

 }
?>