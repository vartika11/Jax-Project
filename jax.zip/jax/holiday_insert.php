<?php
include_once("connection1.php");
if($_POST)
{
 $connect=mysqli_connect("localhost","root","");
 $db=mysqli_select_db($connect,"jax");
 $holiday_Name=$_POST['title'];
 $holiday_Date=$_POST['date'];
 //$Day=$_['day']

 $query=mysqli_query($connect,"INSERT INTO `holiday`(`title`, `date`) VALUES ('$holiday_Name','$holiday_Date')");
 if($query)
{
	echo "Successfully";
}

 }
?>