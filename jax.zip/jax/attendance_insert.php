<?php
include_once("connection1.php");
if($_POST)
{
 $connect=mysqli_connect("localhost","root","");
 $db=mysqli_select_db($connect,"jax");
 $Name=$_POST['name'];
 $Email_Id=$_POST['email'];
 $Department=$_POST['department'];
 $Work_Description=$_POST['work'];
 $Date=$_POST['date'];
 $Total_Hours=$_POST['hours'];
 $Project=$_POST['project'];

  $query=mysqli_query($connect,"INSERT INTO `attendance`( `name`, `email`, `department`, `work`, `date`, `hours`, `project`) VALUES ('$Name','$Email_Id','$Department','$Work_Description','$Date','$Total_Hours','$Project')");
  if($query)
{
	echo "Successfully";
}
 }
?>