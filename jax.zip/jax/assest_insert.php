<?php
include_once("connection1.php");
if($_POST)
{
 $connect=mysqli_connect("localhost","root","");
 $db=mysqli_select_db($connect,"jax");
 $Assest_Name=$_POST['assest_name'];
 $Assest_ID=$_POST['assest_id'];
 $Purchase_Date=$_POST['purchase_date'];
 $Purchase_From=$_POST['purchase_from'];
 $Manufacturer=$_POST['manufacturer'];
 $Model=$_POST['model'];
 $Serial_Number=$_POST['serial_number'];
 $Supplier=$_POST['supplier'];
 $Condition=$_POST['condition'];
 $Warranty=$_POST['warranty'];
 $Value=$_POST['value'];
 $Asset_User=$_POST['asset_user'];
 //$Description=$_POST['description'];


  $query=mysqli_query($connect,"INSERT INTO `assest`(`assest_name`, `assest_id`, `purchase_date`, `purchase_from`, `manufacturer`, `model`, `serial_number`, `supplier`, `condition`, `warranty`, `value`, `asset_user`) VALUES ('$Assest_Name','$Assest_ID','$Purchase_Date','$Purchase_From','$Manufacturer','$Model','$Serial_Number','$Supplier','$Condition','$Warranty','$Value','$Asset_User')");
  if($query)
{
	echo "Successfully";
}
 }
?>