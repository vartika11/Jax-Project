<?php
include_once("connection1.php");
if($_POST)
{
 $connect=mysqli_connect("localhost","root","");
 $db=mysqli_select_db($connect,"jax");
 $First_Name=$_POST['first_name'];
 $Last_Name=$_POST['last_name'];
 $Username=$_POST['username'];
 $Email=$_POST['email'];
 $Password=$_POST['password'];
 $Confirm_Password=$_POST['cpassword']; 
 $Employee_Id=$_POST['employee_id'];
 $Joining_Date=$_POST['joining-date'];
 $Phone=$_POST['phone'];
 $Company=$_POST['company'];
 $Department=$_POST['department'];
 $Designation=$_POST['designation'];



  $query=mysqli_query($connect,"INSERT INTO `allemployee`(`first_name`, `last_name`, `username`, `email`, `password`, `cpassword`, `employee_id`, `joining-date`, `phone`, `company`, `department`, `designation`) VALUES ('$First_Name','$Last_Name','$Username','$Email','$Password','$Confirm_Password','$Employee_Id','$Joining_Date','$Phone','$Company','$Department','$Designation')");
  if($query)
{
	echo "Successfully";
}
 }
?>